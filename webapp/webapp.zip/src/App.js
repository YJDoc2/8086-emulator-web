import React from 'react';
import RootRouter from './components/router';
import './App.css';

function App() {
	return (
		<RootRouter/>
	);
}

export default App;